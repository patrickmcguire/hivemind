django-boostrap-static
======================

Simply the bootstrap static files WITH plugins